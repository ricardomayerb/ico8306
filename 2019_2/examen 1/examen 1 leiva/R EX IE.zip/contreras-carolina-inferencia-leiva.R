#generar variable normal
var20<-rnorm(20,10,2)

#IC 95% CONFIANZA media
n(20)
n 20
n=20
sd=2
alpha=0.01

t.test(var20)

