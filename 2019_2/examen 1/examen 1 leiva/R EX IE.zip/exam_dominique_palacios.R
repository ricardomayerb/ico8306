x<-rnorm(20,10,2)
media<-mean(x)
