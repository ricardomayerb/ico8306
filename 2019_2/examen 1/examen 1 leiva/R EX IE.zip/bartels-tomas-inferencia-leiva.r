X<-sample(10,20, replace=TRUE)
#95%=1.96 y 99%=2.57
t.test=x()
