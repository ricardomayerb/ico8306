#antonia gonzalez gacitua examen inferencia estadistica 30/12/19

#REGUNTA N1
rnorm (20, 10, 4) 
set.seed (1)
dato=rnorm (20, 10, 4)
n<- 20
mean(dato)
s<- 4
t.test(dato, conf.level = 0.95)
IC.para.la.varianza(dato, 0.01)

#PREGUNTA N2
n<-33
s<-3.8
xraya<-18
pt(17, df= 0.90)
