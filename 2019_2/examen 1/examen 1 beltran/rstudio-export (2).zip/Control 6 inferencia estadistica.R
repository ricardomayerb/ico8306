#1) 
varianza<-4
mean<-10
n=20
sd=2

x<-(rnorm(mean,n,sd))

t.test(x)$conf  #95%
t.test(x,conf.level=0.99)$conf #99%


#2)
n=33
s=3.8
media=18
alfa=0.1

H0: u<17
h1: u>17

(Estadistico = (18 - 17 / (4 / sqrt(33)))
  (pValor = 1 - pnorm(Estadistico))


